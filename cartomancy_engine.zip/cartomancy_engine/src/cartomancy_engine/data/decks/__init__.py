"""Bundled deck JSON resources."""
