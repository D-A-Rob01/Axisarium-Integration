from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from .markdown import render_reading_markdown, write_reading_markdown
from .models import ReadingMode
from .reading import draw_cards
from .resources import ResourceLoadError, list_decks as resource_list_decks, list_spreads as resource_list_spreads, load_deck, load_spread


app = typer.Typer(help="Cartomancy Engine reading logger.")


DEFAULT_OUTPUT_DIR = Path("readings")
VALID_MODES = {"reflective", "predictive", "ritual", "creative", "decision-support"}


@app.command("list-decks")
def list_decks() -> None:
    """List bundled deck ids."""
    for deck_id in resource_list_decks():
        typer.echo(deck_id)


@app.command("list-spreads")
def list_spreads() -> None:
    """List bundled spread ids."""
    for spread_id in resource_list_spreads():
        typer.echo(spread_id)


@app.command()
def draw(
    deck: Annotated[str, typer.Option("--deck", help="Bundled deck id.")] = "rider-waite-smith",
    spread: Annotated[str, typer.Option("--spread", help="Bundled spread id.")] = "three-card",
    mode: Annotated[str, typer.Option("--mode", help="Reading mode.")] = "decision-support",
    question: Annotated[str, typer.Option("--question", help="Optional reading question.")] = "",
    no_reversals: Annotated[bool, typer.Option("--no-reversals", help="Draw only upright cards.")] = False,
    output: Annotated[
        Path | None,
        typer.Option("--output", help="Directory for generated Markdown readings."),
    ] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Print Markdown without writing a file.")] = False,
) -> None:
    """Draw a spread and create a Markdown reading note."""
    if mode not in VALID_MODES:
        raise typer.BadParameter(f"Invalid mode '{mode}'. Choose one of: {', '.join(sorted(VALID_MODES))}")

    try:
        loaded_deck = load_deck(deck)
        loaded_spread = load_spread(spread)
        reading = draw_cards(
            loaded_deck,
            loaded_spread,
            mode=mode,  # type: ignore[arg-type]
            question=question,
            allow_reversals=not no_reversals,
        )
    except (ResourceLoadError, ValueError) as exc:
        raise typer.BadParameter(str(exc)) from exc

    markdown = render_reading_markdown(reading)
    if dry_run:
        typer.echo(markdown)
        return

    target_dir = output or DEFAULT_OUTPUT_DIR
    path = write_reading_markdown(reading, target_dir)
    typer.echo(f"Reading written: {path}")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
