# Cartomancy Engine

Local-first Tarot reading logger for Axisarium.

This is not an AI interpretation engine. v0.1 draws cards, records a question and mode, and renders a Markdown note with empty interpretation and audit sections.

## Install

From this folder:

```powershell
pip install -e .
```

For development tests:

```powershell
pip install -e ".[dev]"
pytest
```

## Commands

Basic draw:

```powershell
cartomancy-engine draw --deck rider-waite-smith --spread three-card --mode decision-support
```

Draw with a question:

```powershell
cartomancy-engine draw --deck rider-waite-smith --spread three-card --mode decision-support --question "What should I prioritize this week?"
```

Write to a specific folder:

```powershell
cartomancy-engine draw --deck rider-waite-smith --spread three-card --mode decision-support --question "What should I prioritize this week?" --output "C:\Users\david\OneDrive\Apps\remotely-save\Axisarium\03 Readings\Tarot"
```

Preview without writing:

```powershell
cartomancy-engine draw --deck rider-waite-smith --spread three-card --mode decision-support --question "What should I prioritize this week?" --dry-run
```

List bundled data:

```powershell
cartomancy-engine list-decks
cartomancy-engine list-spreads
```

## Example Markdown Excerpt

```md
---
type: tarot-reading
date: '2026-06-26'
deck: rider-waite-smith
spread: three-card
mode: decision-support
question: 'What should I prioritize this week?'
cards:
- position: 1
  card: The Fool
  orientation: upright
tags:
- tarot
- aletheion
- symbolic-audit
---

# Tarot Reading - 2026-06-26

## Cards Drawn

| Position | Card | Orientation | Keywords |
| --- | --- | --- | --- |
| 1. Current Pattern | The Fool | upright | beginning, risk, innocence, threshold |
```

## v0.1 Boundaries

- Major Arcana only.
- No card images.
- No AI interpretation.
- No Obsidian plugin or daily note insertion.
- No cloud sync or web UI.
