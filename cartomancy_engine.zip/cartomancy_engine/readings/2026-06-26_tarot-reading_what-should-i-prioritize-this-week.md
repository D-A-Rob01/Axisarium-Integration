---
type: tarot-reading
date: '2026-06-26'
deck: rider-waite-smith
spread: three-card
mode: decision-support
question: What should I prioritize this week?
cards:
- position: 1
  card: Temperance
  orientation: upright
- position: 2
  card: The High Priestess
  orientation: reversed
- position: 3
  card: Judgement
  orientation: reversed
tags:
- tarot
- aletheion
- symbolic-audit
---

# Tarot Reading - 2026-06-26

## Question

What should I prioritize this week?

## Spread

three-card

## Cards Drawn

| Position | Card | Orientation | Keywords |
| --- | --- | --- | --- |
| 1. Current Pattern | Temperance | upright | integration, moderation, alchemy, patience |
| 2. Complication | The High Priestess | reversed | withheld knowledge, disconnection, secrecy, ignored intuition |
| 3. Next Move | Judgement | reversed | self-judgment, avoidance, unanswered call, refusal to review |

## Initial Reading

## Practical Counsel

## Action Chosen

## Follow-Up

## Outcome / Audit

- Was this useful?
- Did it clarify action?
- Did I overproject?
- What actually happened?
