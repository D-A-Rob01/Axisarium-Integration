"""Bundled cartomancy data resources."""
