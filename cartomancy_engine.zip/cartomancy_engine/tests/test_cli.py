from __future__ import annotations

import pytest

typer = pytest.importorskip("typer")
from typer.testing import CliRunner

from cartomancy_engine.cli import app


def test_acceptance_draw_writes_one_markdown_note(tmp_path):
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "draw",
            "--deck",
            "rider-waite-smith",
            "--spread",
            "three-card",
            "--mode",
            "decision-support",
            "--question",
            "What should I prioritize this week?",
            "--output",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 0
    notes = list(tmp_path.glob("*.md"))
    assert len(notes) == 1
    content = notes[0].read_text(encoding="utf-8")
    assert "question: What should I prioritize this week?" in content
    assert "| Position | Card | Orientation | Keywords |" in content


def test_dry_run_prints_markdown_and_writes_nothing(tmp_path):
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "draw",
            "--deck",
            "rider-waite-smith",
            "--spread",
            "three-card",
            "--mode",
            "decision-support",
            "--question",
            "What should I prioritize this week?",
            "--output",
            str(tmp_path),
            "--dry-run",
        ],
    )

    assert result.exit_code == 0
    assert "# Tarot Reading -" in result.output
    assert "| Position | Card | Orientation | Keywords |" in result.output
    assert list(tmp_path.glob("*.md")) == []


def test_no_reversals_cli_writes_only_upright_cards(tmp_path):
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "draw",
            "--deck",
            "rider-waite-smith",
            "--spread",
            "three-card",
            "--mode",
            "decision-support",
            "--no-reversals",
            "--output",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 0
    content = next(tmp_path.glob("*.md")).read_text(encoding="utf-8")
    assert "orientation: reversed" not in content
    assert "| upright |" in content


def test_list_commands_show_bundled_resources():
    runner = CliRunner()

    decks = runner.invoke(app, ["list-decks"])
    spreads = runner.invoke(app, ["list-spreads"])

    assert decks.exit_code == 0
    assert "rider-waite-smith" in decks.output
    assert spreads.exit_code == 0
    assert "three-card" in spreads.output
    assert "avoidance-reality-next-move" in spreads.output
