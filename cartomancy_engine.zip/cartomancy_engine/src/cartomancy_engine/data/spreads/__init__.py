"""Bundled spread JSON resources."""
